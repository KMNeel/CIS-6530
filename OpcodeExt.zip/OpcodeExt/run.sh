#!/usr/bin/env bash
set -e

GHIDRA_DIR="$HOME/ghidra_11.3.1_PUBLIC"
ANALYZE="$GHIDRA_DIR/support/analyzeHeadless"

INPUT_FILE="$1"
OUTPUT_DIR="$HOME/Desktop/OpcodeExt/opcodes"
PROJECT_DIR="$HOME/Desktop/OpcodeExt/ghidra_project"
SCRIPT_DIR="$HOME/Desktop/OpcodeExt"

mkdir -p "$PROJECT_DIR"

rel="$(basename "$INPUT_FILE")"
safe=$(echo "$rel" | sed 's#[/[:space:]]#_#g; s#[^A-Za-z0-9._-]#_#g')
out="$OUTPUT_DIR/${safe}.opcode"

if [ -s "$out" ]; then
    echo "Skipping $rel (already extracted)"
    exit 0
fi

echo "Processing $rel"

"$ANALYZE" "$PROJECT_DIR" opcodeProject \
    -import "$INPUT_FILE" \
    -postScript ExtractOpcodes.py "$out" \
    -scriptPath "$SCRIPT_DIR" \
    -deleteProject

echo "Done: $out"
