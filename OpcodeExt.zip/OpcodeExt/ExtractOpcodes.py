from java.io import FileWriter, BufferedWriter

def main():
    args = getScriptArgs()
    if len(args) < 1:
        printerr("Usage: ExtractOpcodes.py <output_file>")
        return

    out_path = args[0]
    listing = currentProgram.getListing()
    instructions = listing.getInstructions(True)

    writer = BufferedWriter(FileWriter(out_path))

    try:
        while instructions.hasNext():
            instr = instructions.next()

            mnemonic = instr.getMnemonicString()
            full_text = instr.toString()

            if full_text:
                writer.write(full_text.lower())
                writer.newLine()
            elif mnemonic:
                writer.write(mnemonic.lower())
                writer.newLine()

        writer.flush()
        print("Opcodes written to:", out_path)

    finally:
        writer.close()

main()
