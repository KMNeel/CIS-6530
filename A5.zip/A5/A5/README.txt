Run cnn_preprocess.py
1.Navigate to PreProcess folder.
2.Open Windows Command Prompt and run the following command: 
py cnn_preprocess.py --data_dir . --output_dir ./cnn_data --max_len 45000
3. After running the script, a new folder named cnn_data would be visible. It would have all the needed data for the cnn_train.py. 

Run cnn_train.py
1.Open cnn_train.py or copy-paste the script into Google Colab under a single cell.
2.Upload the following input files: X_sequences.npy, y_labels.npy, vocabulary.json and label_mapping.json
3.Run the Script ( In this case CPU was used)
4.The script will generate a dedicated folder containing all confusion matrices, statistics and other graphs. 

Note: For submission purposes, all scripts, preprocessing output, final results (confusion matrices, graphs, metric statistics) have been uploaded to GitHub.