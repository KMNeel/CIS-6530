#!/usr/bin/env python3
"""
CNN Preprocessing Script 
Adaptation of McLaughlin et al., "Deep Android Malware Detection"
for pre-extracted .opcode files.

What this script does:
1. Recursively finds .opcode files.
2. Extracts the malware family label from the filename.
3. Reads each file as an ordered opcode sequence, keeping only the mnemonic
   (first token) and discarding operands.
4. Keeps all non-empty samples by default.
5. Builds a global opcode vocabulary.
6. Encodes each sequence as integers.
7. Pads / truncates sequences to a fixed max_len.
8. Saves arrays and metadata for CNN training.

Example usage:
  python cnn_preprocess.py --data_dir ./opcode_dataset --output_dir ./cnn_data
  python cnn_preprocess.py --data_dir ./opcode_dataset --output_dir ./cnn_data --max_len 5000
  python cnn_preprocess.py --data_dir ./opcode_dataset --output_dir ./cnn_data --len_strategy p95
"""

from __future__ import annotations

import argparse
import json
import math
import os
from collections import Counter
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

PAD_TOKEN = "<PAD>"   # index 0
UNK_TOKEN = "<UNK>"   # index 1
DEFAULT_MIN_SEQ_LEN = 1  # keep all non-empty samples by default



# File discovery and label extraction
def discover_files(data_dir: str) -> list[dict[str, str]]:
    """
    Recursively discover .opcode files under data_dir.

    Expected filename convention:
        APTname_VirusShare_md5.opcode

    Returns a list of records containing:
        - path
        - label
        - sample_id
    """
    root = Path(data_dir)
    if not root.exists():
        raise FileNotFoundError(f"Input directory does not exist: {data_dir}")
    if not root.is_dir():
        raise NotADirectoryError(f"Input path is not a directory: {data_dir}")

    records: list[dict[str, str]] = []
    for path in sorted(root.rglob("*.opcode")):
        fname = path.name
        lower = fname.lower()

        if "_virusshare_" in lower:
            split_idx = lower.index("_virusshare_")
            label = fname[:split_idx]
        else:
            label = path.stem

        records.append(
            {
                "path": str(path),
                "label": label,
                "sample_id": path.stem,
            }
        )

    print(f"[Stage 1] Found {len(records)} .opcode files under '{data_dir}'")
    return records



# Opcode extraction 
def extract_opcode_sequence(filepath: str) -> list[str]:
    """
    Read one .opcode file and return the ordered opcode mnemonic sequence.

    For each non-empty, non-comment line:
      - strip whitespace
      - keep only the first whitespace-separated token
      - lowercase it for consistency

    Comment lines beginning with ';' or '#' are skipped.
    """
    opcodes: list[str] = []
    with open(filepath, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if line.startswith(";") or line.startswith("#"):
                continue

            parts = line.split()
            if not parts:
                continue

            mnemonic = parts[0].strip().lower()
            if mnemonic:
                opcodes.append(mnemonic)

    return opcodes


def load_all_sequences(records: list[dict[str, str]], min_seq_len: int) -> list[dict[str, Any]]:
    """
    Extract ordered opcode sequences for all files.
    Samples shorter than min_seq_len are dropped. By default min_seq_len=1,
    which means only empty samples are removed.
    """
    kept: list[dict[str, Any]] = []
    dropped: list[tuple[str, int]] = []

    for rec in records:
        seq = extract_opcode_sequence(rec["path"])
        seq_len = len(seq)
        if seq_len < min_seq_len:
            dropped.append((rec["sample_id"], seq_len))
            continue

        enriched = dict(rec)
        enriched["sequence"] = seq
        enriched["seq_len"] = seq_len
        kept.append(enriched)

    if dropped:
        print(f"[Stage 2] Dropped {len(dropped)} sample(s) shorter than {min_seq_len} opcode(s)")
        for sample_id, seq_len in dropped:
            print(f"          - {sample_id} (length={seq_len})")

    print(f"[Stage 2] Retained {len(kept)} sample(s)")
    return kept



# Vocabulary construction
def build_vocabulary(records: list[dict[str, Any]], min_freq: int = 1) -> dict[str, int]:
    """
    Build a global opcode -> integer index mapping.

    Index 0 -> PAD_TOKEN
    Index 1 -> UNK_TOKEN
    Index 2+ -> opcodes ordered by descending frequency, then alphabetically

    min_freq can be increased to collapse ultra-rare tokens into <UNK>.
    Keep it at 1 by default.
    """
    counter: Counter[str] = Counter()
    for rec in records:
        counter.update(rec["sequence"])

    kept_tokens = [tok for tok, freq in counter.items() if freq >= min_freq]
    kept_tokens.sort(key=lambda tok: (-counter[tok], tok))

    vocab: dict[str, int] = {PAD_TOKEN: 0, UNK_TOKEN: 1}
    for idx, tok in enumerate(kept_tokens, start=2):
        vocab[tok] = idx

    print(
        f"[Stage 3] Vocabulary size = {len(vocab)} "
        f"(kept {len(kept_tokens)} opcode token(s), min_freq={min_freq})"
    )
    return vocab



# Integer encoding
def encode_sequence(sequence: list[str], vocab: dict[str, int]) -> list[int]:
    """Encode a mnemonic sequence as integer IDs."""
    unk_idx = vocab[UNK_TOKEN]
    return [vocab.get(tok, unk_idx) for tok in sequence]



# max_len selection and padding/truncation
def _percentile_length(lengths: list[int], q: float) -> int:
    if not lengths:
        raise ValueError("Cannot compute percentile from an empty list of lengths")
    return max(1, int(math.ceil(float(np.percentile(lengths, q)))))


def compute_max_len(records: list[dict[str, Any]], strategy: str = "p95") -> int:
    """
    Choose a fixed sequence length for padding/truncation.

    Supported strategies:
      - mean
      - median
      - max
      - p90
      - p95
    """
    lengths = [int(rec["seq_len"]) for rec in records]
    if not lengths:
        raise ValueError("No sequence lengths available to compute max_len")

    if strategy == "mean":
        value = int(round(float(np.mean(lengths))))
    elif strategy == "median":
        value = int(round(float(np.median(lengths))))
    elif strategy == "max":
        value = int(max(lengths))
    elif strategy == "p90":
        value = _percentile_length(lengths, 90)
    elif strategy == "p95":
        value = _percentile_length(lengths, 95)
    else:
        raise ValueError(f"Unsupported length strategy: {strategy}")

    return max(1, value)


def pad_or_truncate(encoded: list[int], max_len: int, pad_idx: int = 0) -> list[int]:
    """
    Right-pad or truncate a sequence to max_len.
    This is a batching convenience for CNN training.
    """
    if len(encoded) >= max_len:
        return encoded[:max_len]
    return encoded + [pad_idx] * (max_len - len(encoded))



# Label encoding
def encode_labels(records: list[dict[str, Any]]) -> tuple[list[int], dict[str, int], dict[int, str]]:
    unique_labels = sorted({rec["label"] for rec in records})
    label_to_idx = {label: idx for idx, label in enumerate(unique_labels)}
    idx_to_label = {idx: label for label, idx in label_to_idx.items()}
    integer_labels = [label_to_idx[rec["label"]] for rec in records]

    print(f"[Stage 6] Number of classes = {len(unique_labels)}")
    for label in unique_labels:
        count = sum(1 for rec in records if rec["label"] == label)
        print(f"          {label_to_idx[label]:>2}: {label:<30} ({count} sample(s))")

    return integer_labels, label_to_idx, idx_to_label



# Save helpers
def save_cleaned_sequences(records: list[dict[str, Any]], output_dir: str) -> None:
    """Save one cleaned mnemonic sequence text file per sample for inspection."""
    cleaned_dir = Path(output_dir) / "cleaned_sequences"
    cleaned_dir.mkdir(parents=True, exist_ok=True)

    for rec in records:
        out_path = cleaned_dir / f"{rec['sample_id']}.txt"
        with open(out_path, "w", encoding="utf-8") as f:
            f.write("\n".join(rec["sequence"]))

    print(f"[Save] cleaned_sequences/             saved to {cleaned_dir}")


def save_outputs(
    records: list[dict[str, Any]],
    X: np.ndarray,
    y: np.ndarray,
    vocab: dict[str, int],
    label_to_idx: dict[str, int],
    idx_to_label: dict[int, str],
    output_dir: str,
    max_len: int,
    len_strategy: str,
    min_seq_len: int,
    min_freq: int,
) -> None:
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    np.save(Path(output_dir) / "X_sequences.npy", X)
    print(f"[Save] X_sequences.npy                shape={X.shape}")

    np.save(Path(output_dir) / "y_labels.npy", y)
    print(f"[Save] y_labels.npy                   shape={y.shape}")

    with open(Path(output_dir) / "vocabulary.json", "w", encoding="utf-8") as f:
        json.dump(vocab, f, indent=2)
    print(f"[Save] vocabulary.json                entries={len(vocab)}")

    with open(Path(output_dir) / "label_mapping.json", "w", encoding="utf-8") as f:
        json.dump(
            {
                "label_to_idx": label_to_idx,
                "idx_to_label": {str(k): v for k, v in idx_to_label.items()},
            },
            f,
            indent=2,
        )
    print(f"[Save] label_mapping.json             saved")

    meta_rows = []
    for i, rec in enumerate(records):
        meta_rows.append(
            {
                "sample_id": rec["sample_id"],
                "label": rec["label"],
                "label_idx": int(y[i]),
                "original_len": int(rec["seq_len"]),
                "was_truncated": bool(rec["seq_len"] > max_len),
                "was_padded": bool(rec["seq_len"] < max_len),
                "path": rec["path"],
            }
        )
    pd.DataFrame(meta_rows).to_csv(Path(output_dir) / "sample_metadata.csv", index=False)
    print(f"[Save] sample_metadata.csv            saved")

    stats = {
        "num_samples": int(X.shape[0]),
        "max_len": int(max_len),
        "vocab_size": int(len(vocab)),
        "num_classes": int(len(label_to_idx)),
        "length_strategy": len_strategy,
        "min_seq_len": int(min_seq_len),
        "min_vocab_freq": int(min_freq),
        "sequence_length_min": int(min(rec["seq_len"] for rec in records)),
        "sequence_length_median": float(np.median([rec["seq_len"] for rec in records])),
        "sequence_length_mean": float(np.mean([rec["seq_len"] for rec in records])),
        "sequence_length_max": int(max(rec["seq_len"] for rec in records)),
    }
    with open(Path(output_dir) / "preprocessing_stats.json", "w", encoding="utf-8") as f:
        json.dump(stats, f, indent=2)
    print(f"[Save] preprocessing_stats.json       saved")



# Main pipeline
def run_preprocessing(
    data_dir: str,
    output_dir: str,
    max_len_arg: int | None,
    len_strategy: str,
    min_seq_len: int,
    min_freq: int,
    save_cleaned: bool,
) -> None:
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    records = discover_files(data_dir)
    if not records:
        raise FileNotFoundError(
            f"No .opcode files found under '{data_dir}'. Check your --data_dir path."
        )

    records = load_all_sequences(records, min_seq_len=min_seq_len)
    if not records:
        raise RuntimeError(
            "All samples were dropped after opcode extraction. "
            "Try lowering --min_seq_len."
        )

    if save_cleaned:
        save_cleaned_sequences(records, output_dir)

    vocab = build_vocabulary(records, min_freq=min_freq)

    for rec in records:
        rec["encoded"] = encode_sequence(rec["sequence"], vocab)
    print("[Stage 4] All sequences integer-encoded")

    if max_len_arg is not None:
        max_len = max_len_arg
        print(f"[Stage 5] Using user-supplied max_len = {max_len}")
    else:
        max_len = compute_max_len(records, strategy=len_strategy)
        print(f"[Stage 5] Using '{len_strategy}' strategy -> max_len = {max_len}")

    X_list = [pad_or_truncate(rec["encoded"], max_len=max_len, pad_idx=0) for rec in records]
    X = np.asarray(X_list, dtype=np.int32)

    n_truncated = sum(1 for rec in records if rec["seq_len"] > max_len)
    n_padded = sum(1 for rec in records if rec["seq_len"] < max_len)
    n_exact = sum(1 for rec in records if rec["seq_len"] == max_len)
    print(
        f"          padded={n_padded}, truncated={n_truncated}, exact={n_exact}"
    )

    integer_labels, label_to_idx, idx_to_label = encode_labels(records)
    y = np.asarray(integer_labels, dtype=np.int32)

    save_outputs(
        records=records,
        X=X,
        y=y,
        vocab=vocab,
        label_to_idx=label_to_idx,
        idx_to_label=idx_to_label,
        output_dir=output_dir,
        max_len=max_len,
        len_strategy=len_strategy,
        min_seq_len=min_seq_len,
        min_freq=min_freq,
    )

    print("\n" + "=" * 60)
    print("PREPROCESSING COMPLETE")
    print("=" * 60)
    print(f"Samples           : {X.shape[0]}")
    print(f"Sequence length   : {X.shape[1]}")
    print(f"Vocabulary size   : {len(vocab)}")
    print(f"Number of classes : {len(label_to_idx)}")
    print(f"Output directory  : {output_dir}")
    print("=" * 60)



# CLI
def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Preprocess .opcode files for paper-style CNN malware-family classification"
    )
    parser.add_argument(
        "--data_dir",
        type=str,
        required=True,
        help="Path to the directory containing .opcode files",
    )
    parser.add_argument(
        "--output_dir",
        type=str,
        default="./cnn_data",
        help="Directory where processed outputs will be saved",
    )
    parser.add_argument(
        "--max_len",
        type=int,
        default=None,
        help="Fixed sequence length for padding/truncation. Overrides --len_strategy if supplied.",
    )
    parser.add_argument(
        "--len_strategy",
        type=str,
        default="p95",
        choices=["mean", "median", "max", "p90", "p95"],
        help="How to auto-compute max_len when --max_len is not supplied",
    )
    parser.add_argument(
        "--min_seq_len",
        type=int,
        default=DEFAULT_MIN_SEQ_LEN,
        help="Drop samples shorter than this many opcodes. Default keeps all non-empty samples.",
    )
    parser.add_argument(
        "--min_freq",
        type=int,
        default=1,
        help="Minimum global token frequency to keep in vocabulary. Rarer tokens map to <UNK>.",
    )
    parser.add_argument(
        "--no_save_cleaned",
        action="store_true",
        help="Do not save cleaned text sequences under output_dir/cleaned_sequences",
    )
    return parser


if __name__ == "__main__":
    args = build_arg_parser().parse_args()
    run_preprocessing(
        data_dir=args.data_dir,
        output_dir=args.output_dir,
        max_len_arg=args.max_len,
        len_strategy=args.len_strategy,
        min_seq_len=args.min_seq_len,
        min_freq=args.min_freq,
        save_cleaned=not args.no_save_cleaned,
    )
